from django.contrib import admin
from .models import Confirmations
# Register your models here.

admin.site.register(Confirmations)