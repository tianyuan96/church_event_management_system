from django.apps import AppConfig


class FoodPreferencesConfig(AppConfig):
    name = 'food_preferences'
