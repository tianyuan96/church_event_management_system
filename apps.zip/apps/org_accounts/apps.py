from django.apps import AppConfig


class OrgAccountsConfig(AppConfig):
    name = 'org_accounts'
