from django.test import TestCase

# Create your tests here.
class EntryModelTest(TestCase):

    def test_string_representation(self):
        self.fail("TODO Test incomplete adfad fs ")
